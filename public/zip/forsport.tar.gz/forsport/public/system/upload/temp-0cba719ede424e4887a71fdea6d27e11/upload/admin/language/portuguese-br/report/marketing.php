<?php
// Heading
$_['heading_title']    = 'Relatório de marketing';

// Text
$_['text_list']         = 'Listando marketing';
$_['text_all_status']   = 'Todos as situações';

// Column
$_['column_campaign']  = 'Campanha';
$_['column_code']      = 'Código';
$_['column_clicks']    = 'Cliques';
$_['column_orders']    = 'Pedidos';
$_['column_total']     = 'Total';

// Entry
$_['entry_date_start'] = 'Data inicial';
$_['entry_date_end']   = 'Data final';
$_['entry_status']     = 'Situação do pedido';