<?php
// Text
$_['text_success']     = 'Os pontos foram utilizados com sucesso!';

// Error
$_['error_permission'] = 'Aten��o: Voc� n�o tem permiss�o de acesso a API!';
$_['error_reward']     = 'Aten��o: Insira a quantidade de pontos que deseja utilizar!';
$_['error_points']     = 'Aten��o: Voc� n�o possui %s pontos!';
$_['error_maximum']    = 'Aten��o: O n�mero m�ximo de pontos que pode ser utilizado �: %s!';