<?php
// Heading
$_['heading_title']    = 'Vale presentes';

// Text
$_['text_total']       = 'Total de pedidos';
$_['text_success']	   = 'Vale presentes modificado com sucesso!';
$_['text_edit']        = 'Configurações do Vale presentes';

// Entry
$_['entry_status']     = 'Situação';
$_['entry_sort_order'] = 'Posição';

// Error
$_['error_permission'] = 'Atenção: Você não tem permissão para modificar o Vale presentes!';