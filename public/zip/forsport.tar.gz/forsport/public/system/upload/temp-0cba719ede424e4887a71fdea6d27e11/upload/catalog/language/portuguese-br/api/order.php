<?php
// Text
$_['text_success']           = 'O pedido foi modificado com sucesso';

// Error
$_['error_permission']       = 'Aten��o: Voc� n�o tem permiss�o de acesso a API!';
$_['error_customer']         = 'Os dados do cliente n�o foram informados!';
$_['error_payment_address']  = 'O endere�o para fatura n�o foi informado!';
$_['error_payment_method']   = 'O m�todo de pagamento n�o foi informado!';
$_['error_shipping_address'] = 'O endere�o para entrega n�o foi informado!';
$_['error_shipping_method']  = 'O m�todo de envio n�o foi informado!';
$_['error_stock']            = 'Os produtos marcados com *** n�o est�o dispon�veis na quantia solicitada ou n�o encontram-se em estoque!';
$_['error_minimum']          = 'A quantidade m�nima para %s � %s!';
$_['error_not_found']        = 'Aten��o: O pedido solicitado n�o foi encontrado!';