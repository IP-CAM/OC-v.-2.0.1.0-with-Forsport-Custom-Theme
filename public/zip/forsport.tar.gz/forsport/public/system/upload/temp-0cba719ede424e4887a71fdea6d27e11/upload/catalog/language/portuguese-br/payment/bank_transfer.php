<?php
// Text
$_['text_title']				= 'Dep�sito banc�rio';
$_['text_instruction']			= 'Instru��es';
$_['text_description']			= 'Deposite o valor total do pedido na conta:';
$_['text_payment']				= 'Ap�s o dep�sito, envie a c�pia do comprovante por e-mail, acompanhado dos dados do seu pedido.';