<?php
// Heading
		
				$_['text_category'] = 'Categories';
				$_['text_manufacturer'] = 'Brand:';
				$_['text_model'] = 'Model:';
				$_['text_availability'] = 'Availability:';
				$_['text_instock'] = 'In Stock';
				$_['text_outstock'] = 'Out Stock';
				$_['text_price']        = 'Price: ';
		
				$_['button_details']          = 'Подробнее';
				$_['text_category'] = 'Категория';
				$_['text_manufacturer'] = 'Брєнд';
				$_['text_model'] = 'Модель:';
				$_['text_availability'] = 'Наличие:';
				$_['text_instock'] = 'Доступно';
				$_['text_outstock'] = 'нет в наличии ';
				$_['text_price']        = 'Цена: ';
				$_['text_tax']          = 'налог:';
				$_['text_quick']          = 'Быстрый просмотр'; 
				$_['text_product']          = 'Product {current} of {total} ';
		
				$_['button_details']          = 'Подробнее';
				$_['text_category'] = 'Категория';
				$_['text_manufacturer'] = 'Брєнд';
				$_['text_model'] = 'Модель:';
				$_['text_availability'] = 'Наличие:';
				$_['text_instock'] = 'Доступно';
				$_['text_outstock'] = 'нет в наличии ';
				$_['text_price']        = 'Цена: ';
				$_['text_tax']          = 'налог:';
				$_['text_quick']          = 'Быстрый просмотр'; 
				$_['text_product']          = 'Product {current} of {total} ';
				$_['text_sale']      = 'Скидка';
				
				$_['text_sale']      = 'Скидка';
				
				$_['text_tax']          = 'Ex Tax:';
				$_['text_quick']          = 'Quick View'; 
				$_['button_details']          = 'Details';
				$_['reviews']          = 'reviews ';
				$_['text_product']          = 'Product {current} of {total} ';
				
$_['heading_title'] = 'Акции';

// Text

			$_['text_sale']      = 'Скидка';
			
$_['text_tax']      = 'Без НДС:';

