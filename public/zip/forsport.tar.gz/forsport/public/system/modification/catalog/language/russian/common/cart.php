<?php
// Text
 
			$_['text_items2']    = '%s';
			$_['text_shopping_cart']    = 'Shopping Cart:';
				
$_['text_items']    = 'Товаров %s (%s)';
$_['text_empty']    = 'Ваша корзина пуста!';
$_['text_cart']     = 'Посмотреть корзину';
$_['text_checkout'] = 'Оформление покупки';
 
			$_['text_shopping_cart'] = 'Корзина: ';
				
$_['text_recurring']  = 'Платежный профиль';

