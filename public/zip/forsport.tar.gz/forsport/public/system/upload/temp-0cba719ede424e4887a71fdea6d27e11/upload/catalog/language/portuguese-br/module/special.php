<?php
// Heading
$_['heading_title'] = 'Promoções';

// Text
$_['text_tax']      = 'Sem impostos:';