<?php
// Heading
$_['heading_title']                          = 'Royal Mail';

// Text
$_['text_shipping']                          = 'Frete';
$_['text_success']                           = 'Frete Royal Mail modificado com sucesso!';
$_['text_edit']                              = 'Configurações do frete Royal Mail';

// Entry
$_['entry_rate']                             = 'Preços';
$_['entry_insurance']                        = 'Compensação de preços';
$_['entry_display_weight']                   = 'Peso da entrega';
$_['entry_display_insurance']                = 'Valor do seguro';
$_['entry_weight_class']                     = 'Unidade de peso';
$_['entry_tax_class']                        = 'Grupo de impostos';
$_['entry_geo_zone']                         = 'Região geográfica';
$_['entry_status']                           = 'Situação';
$_['entry_sort_order']                       = 'Posição';

// Help
$_['help_rate']                              = 'Example: 5:10.00,7:12.00 Weight:Cost,Weight:Cost, etc..';
$_['help_insurance']                         = 'Enter values upto 5,2 decimal places. (12345.67) Example: 34:0,100:1,250:2.25 - Insurance cover for cart values upto 34 would cost 0.00 extra, those values more than 100 and upto 250 will cost 2.25 extra. Do not enter currency symbols.';
$_['help_airmail_rate_1']                    = 'Example: 5:10.00,7:12.00 Weight:Cost,Weight:Cost, etc..<br /><br />These rates will only be applied to the below countries:<br />AL, AD, AM, AT, AZ, BY, BE, BA, BG, HR, CY, CZ, DK, EE, FO, FI, FR, GE, DE, GI, GR, GL, HU, IS, IE, IT, KZ, KG, LV, LI, LT, LU, MK, MT, MD, MC, NL, NO, PL, PT, RO, RU, SM, SK, SI, ES, SE, CH, TJ, TR, TM, UA, UZ, VA';
$_['help_airmail_rate_2']                    = 'Example: 5:10.00,7:12.00 Weight:Cost,Weight:Cost, etc..<br /><br />These rates will only be applied to all other countries not in the above list.';
$_['help_international_signed_rate_1']       = 'Example: 5:10.00,7:12.00 Weight:Cost,Weight:Cost, etc..<br /><br />These rates will only be applied to the below countries:<br />AL, AD, AM, AT, AZ, BY, BE, BA, BG, HR, CY, CZ, DK, EE, FO, FI, FR, GE, DE, GI, GR, GL, HU, IS, IE, IT, KZ, KG, LV, LI, LT, LU, MK, MT, MD, MC, NL, NO, PL, PT, RO, RU, SM, SK, SI, ES, SE, CH, TJ, TR, TM, UA, UZ, VA';
$_['help_international_signed_insurance_1']  = 'Enter values upto 5,2 decimal places. (12345.67) Example: 34:0,100:1,250:2.25 - Insurance cover for cart values upto 34 would cost 0.00 extra, those values more than 100 and upto 250 will cost 2.25 extra. Do not enter currency symbols.<br /><br />These rates will only be applied to the below countries:<br />AL, AD, AM, AT, AZ, BY, BE, BA, BG, HR, CY, CZ, DK, EE, FO, FI, FR, GE, DE, GI, GR, GL, HU, IS, IE, IT, KZ, KG, LV, LI, LT, LU, MK, MT, MD, MC, NL, NO, PL, PT, RO, RU, SM, SK, SI, ES, SE, CH, TJ, TR, TM, UA, UZ, VA';
$_['help_international_signed_rate_2']       = 'Example: 5:10.00,7:12.00 Weight:Cost,Weight:Cost, etc..<br /><br />These rates will only be applied to all other countries not in the above list.';
$_['help_international_signed_insurance_2']  = 'Enter values upto 5,2 decimal places. (12345.67) Example: 34:0,100:1,250:2.25 - Insurance cover for cart values upto 34 would cost 0.00 extra, those values more than 100 and upto 250 will cost 2.25 extra. Do not enter currency symbols.<br /><br />These rates will only be applied to all other countries not in the above list.';
$_['help_airsure_rate_1']                    = 'Example: 5:10.00,7:12.00 Weight:Cost,Weight:Cost, etc..<br /><br />These rates will only be applied to the below countries:<br />AD, AT, BE, CH, DE, DK, ES, FO, FI, FR, IE, IS, LI, LU, MC, NL, PT, SE';
$_['help_airsure_insurance_1']               = 'Enter values upto 5,2 decimal places. (12345.67) Example: 34:0,100:1,250:2.25 - Insurance cover for cart values upto 34 would cost 0.00 extra, those values more than 100 and upto 250 will cost 2.25 extra. Do not enter currency symbols.<br /><br />These rates will only be applied to the below countries:<br />AD, AT, BE, CH, DE, DK, ES, FO, FI, FR, IE, IS, LI, LU, MC, NL, PT, SE';
$_['help_airsure_rate_2']                    = 'Example: 5:10.00,7:12.00 Weight:Cost,Weight:Cost, etc..<br /><br />These rates will only be applied to the below countries:<br />BR, CA, HK, MY, NZ, SG, US';
$_['help_airsure_insurance_2']               = 'Enter values upto 5,2 decimal places. (12345.67) Example: 34:0,100:1,250:2.25 - Insurance cover for cart values upto 34 would cost 0.00 extra, those values more than 100 and upto 250 will cost 2.25 extra. Do not enter currency symbols.<br /><br />These rates will only be applied to the below countries:<br />BR, CA, HK, MY, NZ, SG, US';
$_['help_display_weight']                    = 'Do you want to display the shipping weight? (e.g. Delivery Weight : 2.7674 kg)';
$_['help_display_insurance']                 = 'Do you want to display the shipping insurance? (e.g. Insured upto &pound;500)';

// Tab
$_['tab_1st_class_standard']                 = 'First Class Standard Post';
$_['tab_1st_class_recorded']                 = 'First Class Recorded Post';
$_['tab_2nd_class_standard']                 = 'Second Class Standard Post';
$_['tab_2nd_class_recorded']                 = 'Second Class Recorded Post';
$_['tab_special_delivery_500']               = 'Special Delivery Next Day (&pound;500)';
$_['tab_special_delivery_1000']              = 'Special Delivery Next Day (&pound;1000)';
$_['tab_special_delivery_2500']              = 'Special Delivery Next Day (&pound;2500)';
$_['tab_standard_parcels']                   = 'Standard Parcels';
$_['tab_airmail']                            = 'Airmail';
$_['tab_international_signed']               = 'International Signed';
$_['tab_airsure']                            = 'Airsure';
$_['tab_surface']                            = 'Surface';

// Error
$_['error_permission']                       = 'Atenção: Você não tem permissão para modificar o frete Royal Mail!';