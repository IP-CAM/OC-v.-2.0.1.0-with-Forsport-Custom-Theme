<?php
// Text
$_['text_title']       = 'Item';
$_['text_description'] = 'Frete por item';