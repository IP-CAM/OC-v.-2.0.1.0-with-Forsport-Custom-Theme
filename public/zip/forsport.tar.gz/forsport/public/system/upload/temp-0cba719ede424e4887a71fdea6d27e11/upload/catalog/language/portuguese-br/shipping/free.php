<?php
// Text
$_['text_title']       = 'Gr�tis';
$_['text_description'] = 'Frete gr�tis';