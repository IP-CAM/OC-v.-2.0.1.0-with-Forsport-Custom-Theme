<?php
// Heading
$_['heading_title'] = 'Refinar busca';