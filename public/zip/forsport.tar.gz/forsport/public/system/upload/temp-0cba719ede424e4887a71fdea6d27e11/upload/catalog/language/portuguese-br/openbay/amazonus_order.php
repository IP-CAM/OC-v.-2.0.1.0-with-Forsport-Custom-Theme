<?php
// Text
$_['text_paid_amazon'] 			= 'Pagar com Amazon US';
$_['text_total_shipping'] 		= 'Frete';
$_['text_total_shipping_tax'] 	= 'Taxa pelo frete';
$_['text_total_giftwrap'] 		= 'Embrulhar para presente';
$_['text_total_giftwrap_tax'] 	= 'Taxa para embrulhar para presente';
$_['text_total_sub'] 			= 'Sub-total';
$_['text_tax'] 					= 'Impostos';
$_['text_total'] 				= 'Total';