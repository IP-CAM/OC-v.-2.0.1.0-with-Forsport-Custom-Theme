<?php
// Heading
$_['heading_title']    = 'Frete';

// Text
$_['text_total']       = 'Total de pedidos';
$_['text_success']	   = 'Frete modificado com sucesso!';
$_['text_edit']        = 'Configurações do Frete';

// Entry
$_['entry_estimator']  = 'Calcular frete';
$_['entry_status']     = 'Situação';
$_['entry_sort_order'] = 'Posição';

// Error
$_['error_permission'] = 'Atenção: Você não tem permissão para modificar o Frete!';