<?php
// Text
$_['text_title']    = 'Australia Post';
$_['text_express']  = 'Expresso';
$_['text_standard'] = 'Avan�ado';
$_['text_eta']      = 'dias';