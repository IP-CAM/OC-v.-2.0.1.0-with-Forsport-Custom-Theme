<?php
// Text
$_['text_title']				= 'Cart�o de cr�dito ou d�bito (pagamento seguro pelo Perpetual Payments)';
$_['text_credit_card']			= 'Detalhes do cart�o';
$_['text_transaction']			= 'ID da transa��o:';
$_['text_avs']					= 'AVS/CVV:';
$_['text_avs_full_match']		= 'Corresponde completamente';
$_['text_avs_not_match']		= 'N�o corresponde';
$_['text_authorisation']		= 'C�digo de autoriza��o:';

// Entry
$_['entry_cc_number']			= 'N�mero do cart�o';
$_['entry_cc_start_date']		= 'V�lido at�';
$_['entry_cc_expire_date']		= 'Expira em';
$_['entry_cc_cvv2']				= 'C�digo de seguran�a (CVV2)';
$_['entry_cc_issue']			= 'Pergunta de seguran�a';

// Help
$_['help_start_date']			= '(se dispon�vel)';
$_['help_issue']				= '(somente para Maestro e Solo)';