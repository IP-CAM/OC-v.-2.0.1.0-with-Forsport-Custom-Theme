<?php
// Heading
$_['heading_title']    = 'Menu de filtros';

// Text
$_['text_module']      = 'Módulos';
$_['text_success']     = 'Módulo Menu de filtros modificado com sucesso!';
$_['text_edit']        = 'Configurações do módulo Menu de filtros';

// Entry
$_['entry_status']     = 'Situação';

// Error
$_['error_permission'] = 'Atenção: Você não tem permissão para modificar o módulo Menu de filtros!';