<?php
// Text
$_['text_title'] = 'Cart�o de cr�dito ou d�bito (Payza)';