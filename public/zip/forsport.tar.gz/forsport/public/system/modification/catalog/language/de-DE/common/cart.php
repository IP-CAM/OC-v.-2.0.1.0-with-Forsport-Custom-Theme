<?php
/**
 * @version		$Id: cart.php 3750 2014-09-28 16:22:31Z mic $
 * @package		Translation - Frontend
 * @author		mic - http://osworx.net
 * @copyright	2014 OSWorX - http://osworx.net
 * @license		GPL - www.gnu.org/copyleft/gpl.html
 */

// Text
 
			$_['text_items2']    = '%s';
			$_['text_shopping_cart']    = 'Shopping Cart:';
				
$_['text_items']		= '%s Artikel - %s';
$_['text_empty']		= 'Warenkorb ist noch leer.';
$_['text_cart']			= 'Warenkorb ansehen';
$_['text_checkout']		= 'Bezahlen';
 
			$_['text_shopping_cart']= 'Warenkorb: ';
				
$_['text_recurring']	= 'Abozahlung';