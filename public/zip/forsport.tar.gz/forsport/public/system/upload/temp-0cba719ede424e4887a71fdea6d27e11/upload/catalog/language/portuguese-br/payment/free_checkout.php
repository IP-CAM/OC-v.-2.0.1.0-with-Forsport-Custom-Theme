<?php
// Text
$_['text_title'] = 'Pagamento gr�tis';