<?php

$_['text_title'] = 'Cart�o de cr�dito ou d�bito';
$_['button_confirm'] = 'Confirmar';

$_['text_postcode_check'] = 'CEP: %s';
$_['text_security_code_check'] = 'C�digo de seguran�a: %s';
$_['text_address_check'] = 'Endere�o: %s';
$_['text_not_given'] = 'N�o comunicado';
$_['text_not_checked'] = 'N�o verificado';
$_['text_match'] = 'Matched';
$_['text_not_match'] = 'Not matched';
$_['text_payment_details'] = 'Detalhes do pagamento';

$_['entry_card_type'] = 'Tipo de cart�o';